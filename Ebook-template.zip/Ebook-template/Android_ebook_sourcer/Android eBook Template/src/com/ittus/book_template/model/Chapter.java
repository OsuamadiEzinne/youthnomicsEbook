package com.ittus.book_template.model;

public class Chapter {

	public String id;
	public String title;

	public Chapter(String id, String title) {
		this.id = id;
		this.title = title;
	}
}
